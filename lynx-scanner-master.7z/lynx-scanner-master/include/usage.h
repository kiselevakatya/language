/*
    File:    usage.h
    Created: 11 March 2019 at 19:28 Moscow time
    Author:  Гаврилов Владимир Сергеевич
    E-mails: vladimir.s.gavrilov@gmail.com
             gavrilov.vladimir.s@mail.ru
             gavvs1977@yandex.ru
*/

#ifndef USAGE_H
#define USAGE_H
void usage(const char* program_name);
#endif