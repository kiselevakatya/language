/*
    File:    lynx_scaner_delimiter_table.cpp
    Created: 25 March 2019 at 17:35 Moscow time
    Author:  Гаврилов Владимир Сергеевич
    E-mails: vladimir.s.gavrilov@gmail.com
             gavrilov.vladimir.s@mail.ru
             gavvs1977@yandex.ru
*/

#include "../include/lynx_scaner_delimiter_table.h"

namespace lynx_scanner{
    const trans_table::Elem<Lexem_code> delimiters_jump_table[] = {
        {const_cast<char32_t*>(U":"),      Lexem_code::Sq_br_opened,                 1}, // [
        {const_cast<char32_t*>(U""),       Lexem_code::Sq_br_colon_opened,           0}, // [:

        {const_cast<char32_t*>(U":"),      Lexem_code::Round_br_opened,              1}, // (
        {const_cast<char32_t*>(U""),       Lexem_code::Tuple_begin,                  0}, // (:

        {const_cast<char32_t*>(U"]):="),   Lexem_code::Colon,                        1}, // :
        {const_cast<char32_t*>(U""),       Lexem_code::Sq_br_colon_closed,           0}, // :]
        {const_cast<char32_t*>(U""),       Lexem_code::Tuple_end,                    0}, // :)
        {const_cast<char32_t*>(U""),       Lexem_code::Resolution,                   0}, // ::
        {const_cast<char32_t*>(U""),       Lexem_code::Copy,                         0}, // :=

        {const_cast<char32_t*>(U""),       Lexem_code::Sq_br_closed,                 0}, // ]

        {const_cast<char32_t*>(U""),       Lexem_code::Round_br_closed,              0}, // )

        {const_cast<char32_t*>(U"-=<"),    Lexem_code::Less_than,                    1}, // <
        {const_cast<char32_t*>(U""),       Lexem_code::Set_field,                    0}, // <-
        {const_cast<char32_t*>(U">"),      Lexem_code::Less_or_equals_than,          2}, // <=
        {const_cast<char32_t*>(U"="),      Lexem_code::Left_shift,                   2}, // <<
        {const_cast<char32_t*>(U""),       Lexem_code::Spaceship,                    0}, // <=>
        {const_cast<char32_t*>(U""),       Lexem_code::Left_shift_assign,            0}, // <<=

        {const_cast<char32_t*>(U">-.="),   Lexem_code::Minus,                        1}, // -
        {const_cast<char32_t*>(U""),       Lexem_code::Component_is,                 0}, // ->
        {const_cast<char32_t*>(U"<"),      Lexem_code::Prev,                         3}, // --
        {const_cast<char32_t*>(U"="),      Lexem_code::Float_sub,                    3}, // -.
        {const_cast<char32_t*>(U""),       Lexem_code::Minus_assign,                 0}, // -=
        {const_cast<char32_t*>(U""),       Lexem_code::Prev_with_wrapping,           0}, // --<
        {const_cast<char32_t*>(U""),       Lexem_code::Float_minus_assign,           0}, // -.=

        {const_cast<char32_t*>(U"=|&"),    Lexem_code::Logical_not,                  1}, // !
        {const_cast<char32_t*>(U""),       Lexem_code::Not_equals,                   0}, // !=
        {const_cast<char32_t*>(U"|"),      Lexem_code::Maybe_logical_or_not,         2}, // !|
        {const_cast<char32_t*>(U"&"),      Lexem_code::Maybe_logical_and_not,        2}, // !&
        {const_cast<char32_t*>(U".="),     Lexem_code::Logical_or_not,               2}, // !||
        {const_cast<char32_t*>(U".="),     Lexem_code::Logical_and_not,              3}, // !&&
        {const_cast<char32_t*>(U"="),      Lexem_code::Logical_or_not_full,          3}, // !||.
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_or_not_assign,        0}, // !||=
        {const_cast<char32_t*>(U"="),      Lexem_code::Logical_and_not_full,         3}, // !&&.
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_and_not_assign,       0}, // !&&=
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_or_not_full_assign,   0}, // !||.=
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_and_not_full_assign,  0}, // !&&.=

        {const_cast<char32_t*>(U"|&"),     Lexem_code::Bitwise_not,                  1}, // ~
        {const_cast<char32_t*>(U"="),      Lexem_code::Bitwise_or_not,               2}, // ~|
        {const_cast<char32_t*>(U"="),      Lexem_code::Bitwise_and_not,              2}, // ~&
        {const_cast<char32_t*>(U""),       Lexem_code::Bitwise_or_not_assign,        0}, // ~|=
        {const_cast<char32_t*>(U""),       Lexem_code::Bitwise_and_not_assign,       0}, // ~&=

        {const_cast<char32_t*>(U"^="),     Lexem_code::Bitwise_xor,                  1}, // ^
        {const_cast<char32_t*>(U"="),      Lexem_code::Logical_xor,                  2}, // ^^
        {const_cast<char32_t*>(U""),       Lexem_code::Bitwise_xor_assign,           0}, // ^=
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_xor_assign,           0}, // ^^=

        {const_cast<char32_t*>(U"@"),      Lexem_code::At,                           1}, // @
        {const_cast<char32_t*>(U""),       Lexem_code::Data_address,                 0}, // @@

        {const_cast<char32_t*>(U".|"),     Lexem_code::Point,                        1}, // .
        {const_cast<char32_t*>(U""),       Lexem_code::Range,                        0}, // ..
        {const_cast<char32_t*>(U"."),      Lexem_code::Maybe_component_or,           1}, // .|
        {const_cast<char32_t*>(U""),       Lexem_code::Component_or,                 0}, // .|.

        {const_cast<char32_t*>(U"="),      Lexem_code::Assignment,                   1}, // =
        {const_cast<char32_t*>(U""),       Lexem_code::Equals,                       0}, // ==

        {const_cast<char32_t*>(U""),       Lexem_code::Semicolon,                    0}, // ;

        {const_cast<char32_t*>(U"#"),      Lexem_code::Sharp,                        1}, // #
        {const_cast<char32_t*>(U"#"),      Lexem_code::Size_of,                      1}, // ##
        {const_cast<char32_t*>(U""),       Lexem_code::Data_size,                    0}, // ###

        {const_cast<char32_t*>(U"|+.="),   Lexem_code::Plus,                         1}, // +
        {const_cast<char32_t*>(U""),       Lexem_code::Cycle_name_prefix,            0}, // +|
        {const_cast<char32_t*>(U"<"),      Lexem_code::Next,                         3}, // ++
        {const_cast<char32_t*>(U"="),      Lexem_code::Float_add,                    3}, // +.
        {const_cast<char32_t*>(U""),       Lexem_code::Plus_assign,                  0}, // +=
        {const_cast<char32_t*>(U""),       Lexem_code::Next_with_wrapping,           0}, // ++<
        {const_cast<char32_t*>(U""),       Lexem_code::Float_plus_assign,            0}, // +.=

        {const_cast<char32_t*>(U".*=/"),   Lexem_code::Mul,                          1}, // *
        {const_cast<char32_t*>(U"="),      Lexem_code::Float_mul,                    4}, // *.
        {const_cast<char32_t*>(U".="),     Lexem_code::Power,                        4}, // **
        {const_cast<char32_t*>(U""),       Lexem_code::Mul_assign,                   0}, // *=
        {const_cast<char32_t*>(U""),       Lexem_code::Comment_end,                  0}, // */
        {const_cast<char32_t*>(U""),       Lexem_code::Float_mul_assign,             0}, // *.=
        {const_cast<char32_t*>(U"="),      Lexem_code::Float_power,                  2}, // **.
        {const_cast<char32_t*>(U""),       Lexem_code::Power_assign,                 0}, // **=
        {const_cast<char32_t*>(U""),       Lexem_code::Float_power_assign,           0}, // **.=

        {const_cast<char32_t*>(U".=*"),    Lexem_code::Div,                          1}, // /
        {const_cast<char32_t*>(U"="),      Lexem_code::Float_div,                    3}, // /.
        {const_cast<char32_t*>(U""),       Lexem_code::Div_assign,                   0}, // /=
        {const_cast<char32_t*>(U""),       Lexem_code::Comment_begin,                0}, // /*
        {const_cast<char32_t*>(U""),       Lexem_code::Float_div_assign,             0}, // /.=

        {const_cast<char32_t*>(U".="),     Lexem_code::Remainder,                    1}, // %
        {const_cast<char32_t*>(U"="),      Lexem_code::Float_remainder,              2}, // %.
        {const_cast<char32_t*>(U""),       Lexem_code::Remainder_assign,             0}, // %=
        {const_cast<char32_t*>(U""),       Lexem_code::Float_remainder_assign,       0}, // %.=

        {const_cast<char32_t*>(U"|="),     Lexem_code::Bitwise_or,                   1}, // |
        {const_cast<char32_t*>(U".="),     Lexem_code::Logical_or,                   2}, // ||
        {const_cast<char32_t*>(U""),       Lexem_code::Bitwise_or_assign,            0}, // |=
        {const_cast<char32_t*>(U"="),      Lexem_code::Logical_or_full,              2}, // ||.
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_or_assign,            0}, // ||=
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_or_full_assign,       0}, // ||.=

        {const_cast<char32_t*>(U"&="),     Lexem_code::Bitwise_and,                  1}, // &
        {const_cast<char32_t*>(U".="),     Lexem_code::Logical_and,                  2}, // &&
        {const_cast<char32_t*>(U""),       Lexem_code::Bitwise_and_assign,           0}, // &=
        {const_cast<char32_t*>(U"="),      Lexem_code::Logical_and_full,             2}, // &&.
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_and_assign,           0}, // &&=
        {const_cast<char32_t*>(U""),       Lexem_code::Logical_and_full_assign,      0}, // &&.=

        {const_cast<char32_t*>(U">="),     Lexem_code::Greater_than,                 1}, // >
        {const_cast<char32_t*>(U"="),      Lexem_code::Right_shift,                  2}, // >>
        {const_cast<char32_t*>(U""),       Lexem_code::Greater_or_equals_than,       0}, // >=
        {const_cast<char32_t*>(U""),       Lexem_code::Right_shift_assign,           0}, // >>=

        {const_cast<char32_t*>(U"."),      Lexem_code::Cond_op,                      1}, // ?
        {const_cast<char32_t*>(U""),       Lexem_code::Cond_op_full,                 0}, // ?.

        {const_cast<char32_t*>(U"."),      Lexem_code::Curly_brace_opened,           1}, // {
        {const_cast<char32_t*>(U"."),      Lexem_code::Maybe_component,              1}, // {.
        {const_cast<char32_t*>(U"}"),      Lexem_code::Maybe_component,              1}, // {..
        {const_cast<char32_t*>(U""),       Lexem_code::Component,                    0}, // {..}

        {const_cast<char32_t*>(U""),       Lexem_code::Curly_brace_closed,           0}, // }

        {const_cast<char32_t*>(U""),       Lexem_code::Comma,                        0}  // ,
    };
};