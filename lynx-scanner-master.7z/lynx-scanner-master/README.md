Testing of a scanner of the programming language Рысь.
